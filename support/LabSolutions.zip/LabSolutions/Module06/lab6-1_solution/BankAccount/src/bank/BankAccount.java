package bank;

public interface BankAccount {
	int getBalance();
	int getAvailBalance();
	boolean deposit(int amt);
	boolean withdraw(int amt);
	
	// new methods
	boolean credit(int amt);
	boolean debit(int amt);
}