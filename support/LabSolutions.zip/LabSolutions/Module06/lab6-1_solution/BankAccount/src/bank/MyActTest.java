package bank;

import static org.assertj.core.api.Assertions.*;
import static org.junit.Assert.*;

import org.junit.BeforeClass;
//import org.junit.Ignore;
import org.junit.Test;

public class MyActTest {

	private static BankDB myBank;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// Instantiate the mock up bank database before we run and ytes
		MyActTest.myBank = new MockDB();
	}
    //
	// -------- getBalance() and getAvailBalance() tests
	//
	@Test
	public void BAL001() {
		// Case: Get balance from a normal account
		BankAccount b = new MyAct(MyActTest.myBank,5555);
		assertThat(b.getBalance()).as("BAL001 operation").isEqualTo(0);
	}
	
	@Test
	public void BAL002() {
		// Case: Get balance from a non-zero status account
		BankAccount b = new MyAct(MyActTest.myBank,2222);	
		assertThat(b.getBalance()).as("BAL002 operation").isEqualTo(587);
	}
	
	@Test
	public void AVL001() {
		// Case: Get available balance from a normal account
		BankAccount b = new MyAct(MyActTest.myBank,5555);	
		assertThat(b.getAvailBalance()).as("AVL001 operation").isEqualTo(0);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void AVL002() {
		// Case: Throw exception if attempt to get the available
		// balance from a non-zero status account that does not have
		// a $0 available balance
		BankAccount b = new MyAct(MyActTest.myBank,2222);	
	    b.getAvailBalance();
	}
	
	@Test
	public void AVL003() {
		// Case: Get available balance from a normal account
		// with a $0 available balance
		BankAccount b = new MyAct(MyActTest.myBank,4444);	
		assertThat(b.getAvailBalance()).as("AVL003 operation").isEqualTo(0);
	}
	
	@Test
	public void AVL004() {
		// Case: Get available balance from a non-zero status account
		// with a $0 available balance
		BankAccount b = new MyAct(MyActTest.myBank,6666);	
		assertThat(b.getAvailBalance()).as("AVL004 operation").isEqualTo(0);
	}

	//
	// -------- deposit() tests
	//
	
	@Test
	public void DEP001() {
		// Case: Deposit a valid amount into a zero status account
		BankAccount b = new MyAct(MyActTest.myBank,3333);
		assertThat(b.deposit(1)).as("DEP001 operation").isTrue();
		assertThat(b.getBalance()).as("DEP001 Balance()").isEqualTo(898);
		assertThat(b.getAvailBalance()).as("DEP001 Available Balance").isEqualTo(239);
	}
	
	@Test
	public void DEP002() {
		// Case: Deposit valid amount into a non-zero status account
		BankAccount b = new MyAct(MyActTest.myBank, 2222);
		assertFalse("DEP002 operation failed", b.deposit(1));
		assertEquals("DEP002 wrong balance", 587, b.getBalance());
		// cannot check because exception will be thrown
		// assertEquals("DEP002 wrong available balance",346,b.getAvailBalance());
	}
	
	@Test
	public void DEP002alternate() {
		// This might be a good test to include since it does
		// not involve a "broken" account
		BankAccount b = new MyAct(MyActTest.myBank, 6666);
		assertThat(b.deposit(1)).as("DEP002a operation").isFalse();
		assertThat(b.getBalance()).as("DEP002a Balance()").isEqualTo(500);
		assertThat(b.getAvailBalance()).as("DEP002a Available Balance").isEqualTo(0);
	}

	@Test
	public void DEP003() {
		// Case: Deposit invalid amount into a valid account
		BankAccount b = new MyAct(MyActTest.myBank, 1111);
		assertThat(b.deposit(-1)).as("DEP003 operation").isFalse();
		assertThat(b.getBalance()).as("DEP003 Balance()").isEqualTo(1000);
		assertThat(b.getAvailBalance()).as("DEP003 Available Balance").isEqualTo(1000);
	}
	
	//
	// -------- withdraw() tests
	//
	
	@Test
	public void WTH001() {
		// Case: Valid withdrawal works as advertised.
		BankAccount b = new MyAct(MyActTest.myBank,3333);
		assertThat(b.withdraw(1)).as("WTH001 operation").isTrue();
		assertThat(b.getBalance()).as("WTH001 Balance()").isEqualTo(896);
		assertThat(b.getAvailBalance()).as("WTH001 Available Balance").isEqualTo(238);
		

	}
	@Test
	public void WTH002() {
		// Case: Attempt to withdraw from a non-zero status account
		BankAccount b = new MyAct(MyActTest.myBank,6666);
		assertThat(b.withdraw(1)).as("WTH002 operation").isFalse();
		assertThat(b.getBalance()).as("WTH002 Balance()").isEqualTo(500);
		assertThat(b.getAvailBalance()).as("WTH002 Available Balance").isEqualTo(0);

	}
	@Test
	public void WTH003() {
		// Case: Attempt to withdraw invalid amount
		BankAccount b = new MyAct(MyActTest.myBank, 1111);
		assertThat(b.withdraw(-1)).as("WTH003 operation").isFalse();
		assertThat(b.getBalance()).as("WTH003 Balance()").isEqualTo(1000);
		assertThat(b.getAvailBalance()).as("WTH003 Available Balance").isEqualTo(1000);
	

	}
	@Test
	public void WTH004() {
		// Case: Amount withdrawn exceeds available balance
		BankAccount b = new MyAct(MyActTest.myBank, 3333);
		assertThat(b.withdraw(240)).as("WTH004 operation").isFalse();
		assertThat(b.getBalance()).as("WTH004 Balance()").isEqualTo(897);
		assertThat(b.getAvailBalance()).as("WTH004 Available Balance").isEqualTo(239);
		
	}
	@Test
	public void WTH005() {
		// Case: Amount withdrawn exceeds transaction limit
		BankAccount b = new MyAct(MyActTest.myBank, 1111);
		assertThat(b.withdraw(101)).as("WTH005 operation").isFalse();
		assertThat(b.getBalance()).as("WTH005 Balance()").isEqualTo(1000);
		assertThat(b.getAvailBalance()).as("WTH005 Available Balance").isEqualTo(1000);
	}
	
	@Test
	public void WTH006() {
		// Case: Amount withdrawn exceeds session limit
		BankAccount b = new MyAct(MyActTest.myBank, 1111);
		assertThat( b.withdraw(100)).as("WTH006 setup").isTrue();
		assertThat( b.withdraw(100)).as("WTH006 setup").isTrue();
		assertThat( b.withdraw(100)).as("WTH006 setup").isTrue();
		assertThat( b.withdraw(100)).as("WTH006 setup").isTrue();
		assertThat( b.withdraw(100)).as("WTH006 setup").isTrue();
		assertThat( b.withdraw(1)).as("WTH006 operation").isFalse();
		assertThat(b.getBalance()).as("WTH006 Balance()").isEqualTo(500);
		assertThat(b.getAvailBalance()).as("WTH006 Available Balance").isEqualTo(500);
	}
	
	//
	// -------- Constructor tests
	//
	
	@Test (expected = IllegalArgumentException.class)
	public void CON001() {
		// Case: Null pointer from trying to get a non-existent bank account
		new MyAct(MyActTest.myBank,9999);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON002() {
		// Case: Negative balance
		new MyAct(MyActTest.myBank,9111);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON003() {
		// Case: Negative available balance
		new MyAct(MyActTest.myBank,9112);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON004() {
		// Case: Negative Transaction limit
		new MyAct(MyActTest.myBank,9113);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON005() {
		// Case: Negative Session limit
		new MyAct(MyActTest.myBank,9114);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON006() {
		// Case: Available balance > balance
		new MyAct(MyActTest.myBank,9115);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON007() {
		// Case: Transaction limit > session limit
		new MyAct(MyActTest.myBank,9116);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON008() {
		// Case: Illegal Status Code
		new MyAct(MyActTest.myBank,9117);	
	}
}
