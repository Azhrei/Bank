
// This is an implementation class for the Calculator
// interface

public class CalcImp implements Calculator {

	public int div(int x, int y) {
		if (y == 0) throw new IllegalArgumentException();
		return x/y;
	}
	
	public int add(int x, int y) {
		return 0;
	}

	public int sub(int x, int y) {
		return 0;
	}

	public int mult(int x, int y) {
		return 0;
	}



}
