import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalcImpTest {
	
	@Test
	public void testDiv001() {
	  Calculator c = new CalcImp();
	  assertEquals("Div001 Test",2,c.div(6,3));
	}
	@Test (expected = IllegalArgumentException.class)
	public void testDiv002() {
	  Calculator c = new CalcImp();
	  c.div(6,0);
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//System.out.println("========= Before Class");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		//System.out.println("========= After Class");
	}

	@Before
	public void setUp() throws Exception {
		//System.out.println("--- Before ");
	}

	@After
	public void tearDown() throws Exception {
		//System.out.println("--- After ");
	}

	
}
