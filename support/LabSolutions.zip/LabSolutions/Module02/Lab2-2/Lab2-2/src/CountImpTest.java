import static org.junit.Assert.*;

import org.junit.Test;

public class CountImpTest {

	@Test
	// Testing string with a blank 
	public void test01() {
		Counter c = new CountImp();
		assertTrue(c.blankCount("Hi There"));
	}

	@Test
	// Testing string with no blank 
	public void test2o() {
	Counter c = new CountImp();
	assertFalse(c.blankCount("HiThere"));
	}
	
	@Test (expected = IllegalArgumentException.class)
	// Testing empty string 
	public void test03() {
		Counter c = new CountImp();
		assertFalse(c.blankCount(""));
	}

	@Test (expected = IllegalArgumentException.class)
	// Testing string with a blank 
	public void test04() {
		Counter c = new CountImp();
	    String n = null;
		assertFalse(c.blankCount(n));
	}


}
