
public class CountImp implements Counter {

	public boolean blankCount(String s) {
		if (s == null || s == "") throw new IllegalArgumentException();
		if (-1 == s.indexOf(' ')) return false;
		return true;
	}

}
