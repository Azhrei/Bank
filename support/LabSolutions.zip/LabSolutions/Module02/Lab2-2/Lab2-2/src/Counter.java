
public interface Counter {
	public boolean blankCount(String s);
}
