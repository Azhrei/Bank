package bank;

public class MyAct implements BankAccount { 
	 
		// instance variables 
	    private boolean ok;
		private int balance; 
		private int available_balance; 
		private int transaction_limit; 
		private int session_limit; 
		private int total_this_session; 
	 
	public MyAct(BankDB b, int actnum) {
		BankDB myBank = b;
		int[] data = null;
		data = myBank.getData(actnum);
		// null pointer check
		if (data == null) throw new IllegalArgumentException();
		
		ok = (data[0] == 0);
		balance = data[1];
		available_balance = data[2];
		transaction_limit = data[3];
		session_limit = data[4];
		total_this_session = 0;
			
	}
		public int getBalance()  { 
			return balance; 
		} 
	 
    	public int getAvailBalance(){ 
    		// broken available balance
    		if (!ok && available_balance != 0) throw new IllegalArgumentException();
    	    return available_balance; 
    	} 
    
    	public boolean deposit(int amt) { 
    		if (!ok) return false;
    		if (amt <= 0) return false;
    		balance += amt;
    		return true ; 
    	} 
    
    	public boolean withdraw(int amt) { 
    		if (!ok) return false;
    		if (amt <= 0) return false;
    		if (amt > available_balance) return false;
    		if (amt > transaction_limit) return false;
    		if (amt + total_this_session > session_limit) return false;
    		balance -= amt;
    		available_balance -= amt;
    		total_this_session += amt;
    		return true; 
    	} 
	}













