package bank;

// The Bank defined standard transaction types.
enum TransType {Query, Credit, Debit, Other}

// The Receipt class encapsulates the details of
// the transaction just executed
public class Receipt {
	private boolean success; // true if the transaction worked
	private TransType t;
	private int balance;
	private int availBalance;
	private int transAmt;
	

   	public Receipt (boolean s,
   			TransType trans,
   			int bal, int abal, int amt) {
   		this.success = s;
   		this.t = trans ;
   		this.balance = bal;
   		this.availBalance = abal;
   		this.transAmt = amt;
   	}
   	
	public boolean isSuccess() {
		return success;
	}
	public TransType getTransactionType() {
		return t;
	}
	public int getBalance() {
		return balance;
	}
	public int getAvailBalance() {
		return availBalance;
	}
	public int getTransAmt() {
		return transAmt;
	}   			
}