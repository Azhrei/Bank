package bank;

public interface BankAccount {
	Currency getBalance();
	Currency getAvailBalance();
	Receipt credit(Currency amt);
	Receipt debit(Currency amt);

}