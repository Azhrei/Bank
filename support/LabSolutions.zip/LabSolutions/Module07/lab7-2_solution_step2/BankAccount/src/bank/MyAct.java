package bank;

import java.util.ArrayList;
import java.util.Arrays;

public class MyAct implements BankAccount {

	// instance variables
	private boolean ok;
	private int balance;
	private int available_balance;
	private int transaction_limit;
	private int session_limit;
	private int total_this_session;

	public MyAct(BankDB b, int actnum) {
		BankDB myBank = b;
		int[] data = null;
		// load data from "database"
		data = myBank.getData(actnum);

		// null pointer check for non-existent accounts
		if (data == null)
			throw new IllegalArgumentException();

		// assign to instance variables and do correctness checks
		ok = (data[0] == 0);
		balance = data[1];
		available_balance = data[2];
		transaction_limit = data[3];
		session_limit = data[4];
		total_this_session = 0;
		if (balance < 0 || available_balance < 0 || transaction_limit < 0 || session_limit < 0
				|| available_balance > balance || transaction_limit > session_limit) {
			throw new CorruptAccountException();
		}
		ArrayList<Integer> status_codes = new ArrayList<Integer>(Arrays.asList(0, 1, 2, 5, 7, 10, 23, 34, 99));
		if (!status_codes.contains(data[0]))
			throw new CorruptAccountException();
	}

	// -- New Interface Methods
	
	public Currency getBalance() {
		return new Currency(balance);
	}
	
	public Currency getAvailBalance() {
		if (!ok && available_balance != 0) throw new IllegalArgumentException();
		return new Currency(available_balance);
	}
	
	public Receipt credit(Currency amt) {
		boolean s = increase(amt.getAmount());
		return new Receipt(s,TransType.Credit,balance,available_balance,amt.getAmount());
	}
	public Receipt debit(Currency amt) {
		return null;
	}
	

	//
	// -- Private existing methods
	//
	

	private boolean increase(int amt) {
		if (!ok)
			return false;
		if (amt <= 0)
			return false;
		balance += amt;
		return true;
	}

	
	private boolean decrease(int amt){
		if (!ok)
			return false;
		if (amt <= 0)
			return false;
		if (amt > available_balance)
			return false;
		if (amt > transaction_limit)
			return false;
		if (amt + total_this_session > session_limit)
			return false;
		balance -= amt;
		available_balance -= amt;
		total_this_session += amt;
		return true;
	}
}


