package bank;

// This is a conceptual object consisting of an amount
// and a currency which defaults to US Dollars.

public class Currency {
	private int amount;
	private String cur; // Defaults to US Dollars
	
	public Currency(int amt, String c) {
		this.amount = amt;
		this.cur = c;
	}
	public Currency(int amt) {
		this.amount = amt;
		this.cur = "USD";
	}
	public int getAmount() {
		return amount;
	}
	public String getCur() {
		return cur;
	}

}
