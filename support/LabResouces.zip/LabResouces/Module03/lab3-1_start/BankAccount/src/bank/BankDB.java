package bank;

public interface BankDB {
	public int[] getData(int accountNumber);
	public void putData(int[] data);
}
