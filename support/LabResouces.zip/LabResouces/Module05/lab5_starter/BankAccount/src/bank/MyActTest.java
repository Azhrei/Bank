package bank;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class MyActTest {

	private static BankDB myBank;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		MyActTest.myBank = new MockDB();
	}

	@Test
	public void BAL001() {
		// Case: Get balance from a normal account
		BankAccount b = new MyAct(MyActTest.myBank,5555);
		assertEquals("BAL001 operation failed",0,b.getBalance());
	}
	@Test
	public void BAL002() {
		// Case: Get balance from a non-zero status account
		BankAccount b = new MyAct(MyActTest.myBank,2222);	
		assertEquals("BAL002 operation failed",587,b.getBalance());
	}
	@Test
	public void AVL001() {
		// Case: Get available balance from a normal account
		BankAccount b = new MyAct(MyActTest.myBank,5555);	
		assertEquals("AVL001 operation failed",0,b.getAvailBalance());
	}
	@Test (expected = IllegalArgumentException.class)
	public void AVL002() {
		// Case: Throw exception if attempt to get the available
		// balance from a non-zero status account that does not have
		// a $0 available balance
		BankAccount b = new MyAct(MyActTest.myBank,2222);	
	    b.getAvailBalance();
	}
	
	@Test
	public void AVL003() {
		// Case: Get available balance from a normal account
		// with a $0 available balance
		BankAccount b = new MyAct(MyActTest.myBank,4444);	
		assertEquals("AVL003 operation failed",0,b.getAvailBalance());
	}
	
	@Test
	public void AVL004() {
		// Case: Get available balance from a non-zero status account
		// with a $0 available balance
		BankAccount b = new MyAct(MyActTest.myBank,6666);	
		assertEquals("AVL004 operation failed",0,b.getAvailBalance());
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void CON001() {
		// Case: Null pointer from trying to get a non-existent bank account
		new MyAct(MyActTest.myBank,9999);	
	}
	@Test
	public void DEP001() {
		// Case: Legal deposit into a normal account
		BankAccount b = new MyAct(MyActTest.myBank,3333);
		assertTrue("DEP001 operation failed",b.deposit(1));
		assertEquals("DEP001 failed",239,b.getAvailBalance());
		assertEquals("DEP001 wrong balance",898,b.getBalance());
	}
	
	@Test
	public void DEP002() {
		// Case: Deposit into account with non-zero status
		BankAccount b = new MyAct(MyActTest.myBank, 2222);
		assertFalse("DEP002 operation failed", b.deposit(1));
		assertEquals("DEP002 wrong balance", 587, b.getBalance());
		// cannot check because exception will be thrown
		// assertEquals("DEP002 wrong available balance",346,b.getAvailBalance());

	}
	@Test
	public void DEP002alternate() {
		// This might be agood test to include since it does
		// not involve a "broken" account
		BankAccount b = new MyAct(MyActTest.myBank, 6666);
		assertFalse("DEP002a operation failed", b.deposit(1));
		assertEquals("DEP002a wrong balance", 500, b.getBalance());
		assertEquals("DEP002a wrong available balance",0,b.getAvailBalance());

	}

	@Test
	public void DEP003() {
		//Case: Deposit an illegal amount into a normal account
		BankAccount b = new MyAct(MyActTest.myBank, 1111);
		assertFalse("DEP003 operation failed", b.deposit(-1));
		assertEquals("DEP003 wrong balance", 1000, b.getBalance());
		assertEquals("DEP003 wrong available balance",1000,b.getAvailBalance());

	}


}
