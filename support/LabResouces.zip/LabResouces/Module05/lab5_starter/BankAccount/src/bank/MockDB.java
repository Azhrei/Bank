package bank;

public class MockDB implements BankDB {
	
	   public int [] getData (int accountNumber) {
		   int[] data = null;

		   if (accountNumber == 1111) {
			   data = new int[5];
			   data[0] = 0;
			   data[1] = 1000;
			   data[2] = 1000;
			   data[3] = 100;
			   data[4] = 500;
		   }
		   else  if (accountNumber == 2222) {
			   data = new int[5];
			   data[0] = 1;
			   data[1] = 587;
			   data[2] = 346;
			   data[3] = 100;
			   data[4] = 800;
		   }
		   else if (accountNumber == 3333) {
			   data = new int[5];
			   data[0] = 0;
			   data[1] = 897;
			   data[2] = 239;
			   data[3] = 1000;
			   data[4] = 10000;
		   }
		   else if (accountNumber == 4444) {
			   data = new int[5];
			   data[0] = 0;
			   data[1] = 397;
			   data[2] = 0;
			   data[3] = 300;
			   data[4] = 1000;
		   }
		   else if (accountNumber == 5555) {
			   data = new int[5];
			   data[0] = 0;
			   data[1] = 0;
			   data[2] = 0;
			   data[3] = 100;
			   data[4] = 500;
		   }
		   else if (accountNumber == 6666) {
			   data = new int[5];
			   data[0] = 1;
			   data[1] = 500;
			   data[2] = 0;
			   data[3] = 100;
			   data[4] = 600;
		   }
		   // data[] is already null so asking for account 9999
		   // will return a null pointer.
		   return data;
	}
	public void putData(int[] data) {
		return;
	}
	
}

