package bank;

public class CorruptAccountException extends RuntimeException {

	/**
	 * This is just added to suppress the warning.  
	 * The variable is not required in reality
	 */
	private static final long serialVersionUID = 1L;

}
