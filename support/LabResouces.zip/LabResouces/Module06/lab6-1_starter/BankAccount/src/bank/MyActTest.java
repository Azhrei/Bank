package bank;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
//import org.junit.Ignore;
import org.junit.Test;

public class MyActTest {

	private static BankDB myBank;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// Instantiate the mock up bank database before we run and ytes
		MyActTest.myBank = new MockDB();
	}
    //
	// -------- getBalance() and getAvailBalance() tests
	//
	@Test
	public void BAL001() {
		// Case: Get balance from a normal account
		BankAccount b = new MyAct(MyActTest.myBank,5555);
		assertEquals("BAL001 operation failed",0,b.getBalance());
	}
	
	@Test
	public void BAL002() {
		// Case: Get balance from a non-zero status account
		BankAccount b = new MyAct(MyActTest.myBank,2222);	
		assertEquals("BAL002 operation failed",587,b.getBalance());
	}
	
	@Test
	public void AVL001() {
		// Case: Get available balance from a normal account
		BankAccount b = new MyAct(MyActTest.myBank,5555);	
		assertEquals("AVL001 operation failed",0,b.getAvailBalance());
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void AVL002() {
		// Case: Throw exception if attempt to get the available
		// balance from a non-zero status account that does not have
		// a $0 available balance
		BankAccount b = new MyAct(MyActTest.myBank,2222);	
	    b.getAvailBalance();
	}
	
	@Test
	public void AVL003() {
		// Case: Get available balance from a normal account
		// with a $0 available balance
		BankAccount b = new MyAct(MyActTest.myBank,4444);	
		assertEquals("AVL003 operation failed",0,b.getAvailBalance());
	}
	
	@Test
	public void AVL004() {
		// Case: Get available balance from a non-zero status account
		// with a $0 available balance
		BankAccount b = new MyAct(MyActTest.myBank,6666);	
		assertEquals("AVL004 operation failed",0,b.getAvailBalance());
	}

	//
	// -------- deposit() tests
	//
	
	@Test
	public void DEP001() {
		// Case: Deposit a valid amount into a zero status account
		BankAccount b = new MyAct(MyActTest.myBank,3333);
		assertTrue("DEP001 operation failed",b.deposit(1));
		assertEquals("DEP001 wrong balance",239,b.getAvailBalance());
		assertEquals("DEP001 wrong available balance",898,b.getBalance());
	}
	
	@Test
	public void DEP002() {
		// Case: Deposit valid amount into a non-zero status account
		BankAccount b = new MyAct(MyActTest.myBank, 2222);
		assertFalse("DEP002 operation failed", b.deposit(1));
		assertEquals("DEP002 wrong balance", 587, b.getBalance());
		// cannot check because exception will be thrown
		// assertEquals("DEP002 wrong available balance",346,b.getAvailBalance());
	}
	
	@Test
	public void DEP002alternate() {
		// This might be a good test to include since it does
		// not involve a "broken" account
		BankAccount b = new MyAct(MyActTest.myBank, 6666);
		assertFalse("DEP002a operation failed", b.deposit(1));
		assertEquals("DEP002a wrong balance", 500, b.getBalance());
		assertEquals("DEP002a wrong available balance",0,b.getAvailBalance());

	}

	@Test
	public void DEP003() {
		// Case: Deposit invalid amount into a valid account
		BankAccount b = new MyAct(MyActTest.myBank, 1111);
		assertFalse("DEP003 operation failed", b.deposit(-1));
		assertEquals("DEP003 wrong balance", 1000, b.getBalance());
		assertEquals("DEP003 wrong available balance",1000,b.getAvailBalance());
	}
	
	//
	// -------- withdraw() tests
	//
	
	@Test
	public void WTH001() {
		// Case: Valid withdrawal works as advertised.
		BankAccount b = new MyAct(MyActTest.myBank,3333);
		assertTrue("WTH001 operation failed", b.withdraw(1));
		assertEquals("WTH001 wrong balance", 896, b.getBalance());
		assertEquals("WTH001 wrong available balance",238,b.getAvailBalance());

	}
	@Test
	public void WTH002() {
		// Case: Attempt to withdraw from a non-zero status account
		BankAccount b = new MyAct(MyActTest.myBank,6666);
		assertFalse("WTH002 operation failed", b.withdraw(1));
		assertEquals("WTH002 wrong balance", 500, b.getBalance());
		assertEquals("WTH003 wrong available balance",0,b.getAvailBalance());

	}
	@Test
	public void WTH003() {
		// Case: Attempt to withdraw invalid amount
		BankAccount b = new MyAct(MyActTest.myBank, 1111);
		assertFalse("WTH003 operation failed", b.withdraw(-1));
		assertEquals("WTH003 wrong balance", 1000, b.getBalance());
		assertEquals("WTH003 wrong available balance",1000,b.getAvailBalance());

	}
	@Test
	public void WTH004() {
		// Case: Amount withdrawn exceeds available balance
		BankAccount b = new MyAct(MyActTest.myBank, 3333);
		assertFalse("WTH004 operation failed", b.withdraw(240));
		assertEquals("WTH004 wrong balance", 897, b.getBalance());
		assertEquals("WTH004 wrong available balance",239,b.getAvailBalance());

	}
	@Test
	public void WTH005() {
		// Case: Amount withdrawn exceeds transaction limit
		BankAccount b = new MyAct(MyActTest.myBank, 1111);
		assertFalse("WTH005 operation failed", b.withdraw(101));
		assertEquals("WTH005 wrong balance", 1000, b.getBalance());
		assertEquals("WTH005 wrong available balance",1000,b.getAvailBalance());
	}
	
	@Test
	public void WTH006() {
		// Case: Amount withdrawn exceeds session limit
		BankAccount b = new MyAct(MyActTest.myBank, 1111);
		assertTrue("WTH006 setup failed", b.withdraw(100));
		assertTrue("WTH006 setup failed", b.withdraw(100));
		assertTrue("WTH006 setup failed", b.withdraw(100));
		assertTrue("WTH006 setup failed", b.withdraw(100));
		assertTrue("WTH006 setup failed", b.withdraw(100));
		assertFalse("WTH006 operation failed", b.withdraw(1));
		assertEquals("WTH006 wrong balance",500, b.getBalance());
		assertEquals("WTH006 wrong available balance",500,b.getAvailBalance());
	}
	
	//
	// -------- Constructor tests
	//
	
	@Test (expected = IllegalArgumentException.class)
	public void CON001() {
		// Case: Null pointer from trying to get a non-existent bank account
		new MyAct(MyActTest.myBank,9999);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON002() {
		// Case: Negative balance
		new MyAct(MyActTest.myBank,9111);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON003() {
		// Case: Negative available balance
		new MyAct(MyActTest.myBank,9112);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON004() {
		// Case: Negative Transaction limit
		new MyAct(MyActTest.myBank,9113);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON005() {
		// Case: Negative Session limit
		new MyAct(MyActTest.myBank,9114);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON006() {
		// Case: Available balance > balance
		new MyAct(MyActTest.myBank,9115);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON007() {
		// Case: Transaction limit > session limit
		new MyAct(MyActTest.myBank,9116);	
	}
	
	@Test (expected = CorruptAccountException.class)
	public void CON008() {
		// Case: Illegal Status Code
		new MyAct(MyActTest.myBank,9117);	
	}
}
